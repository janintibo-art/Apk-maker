package com.example.apkmaker

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * Aperçu local sans génération d'APK : le site (extrait dans le stockage interne) est
 * servi à une WebView via WebViewAssetLoader. Rien ne quitte l'appareil.
 */
object PreviewManager {
    private fun previewDir(context: Context) = File(context.filesDir, "preview")

    /** Extrait le ZIP, repère la racine web et place son contenu dans filesDir/preview. */
    fun prepare(context: Context, zipUri: Uri): File {
        val dir = previewDir(context).apply { deleteRecursively(); mkdirs() }
        val tmp = File(context.cacheDir, "prev_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            ZipUtil.extract(context, zipUri, tmp)
            val root = WebRootFinder.find(tmp)
            root.copyRecursively(dir, overwrite = true)
        } finally {
            tmp.deleteRecursively()
        }
        return dir
    }

    fun hasPreview(context: Context) = File(previewDir(context), "index.html").exists()

    /** Propose d'épingler un raccourci d'aperçu sur l'écran d'accueil. */
    fun pinShortcut(context: Context, label: String) {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return
        val intent = Intent(context, PreviewActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
        val shortcut = ShortcutInfoCompat.Builder(context, "preview")
            .setShortLabel(label.ifBlank { "Aperçu" })
            .setIcon(IconCompat.createWithResource(context, android.R.drawable.sym_def_app_icon))
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(context, shortcut, null)
    }
}

class PreviewActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val previewDir = File(filesDir, "preview")

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/preview/", WebViewAssetLoader.InternalStoragePathHandler(this, previewDir))
            .build()

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidx.org/preview/index.html")
    }
}
