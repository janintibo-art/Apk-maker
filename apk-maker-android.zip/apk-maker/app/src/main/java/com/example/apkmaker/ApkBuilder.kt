package com.example.apkmaker

import android.content.Context
import android.net.Uri
import com.android.apksig.ApkSigner
import java.io.File

/** Signature V1+V2+V3 via la bibliothèque apksig (entrée déjà alignée). */
object ApkSignerHelper {
    fun sign(input: File, output: File, material: SigningMaterial) {
        val signerConfig = ApkSigner.SignerConfig.Builder(
            "CERT",
            material.privateKey,
            listOf(material.certificate)
        ).build()

        ApkSigner.Builder(listOf(signerConfig))
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setInputApk(input)
            .setOutputApk(output)
            .build()
            .sign()
    }
}

/** Localise le dossier contenant index.html dans l'arborescence extraite. */
object WebRootFinder {
    fun find(root: File): File {
        if (File(root, "index.html").exists()) return root
        val dirs = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
        if (dirs.size == 1 && File(dirs[0], "index.html").exists()) return dirs[0]
        val found = root.walkTopDown()
            .filter { it.isFile && it.name.equals("index.html", ignoreCase = true) }
            .firstOrNull()
            ?: throw IllegalStateException("Aucun index.html trouvé dans le ZIP.")
        return found.parentFile!!
    }
}

/**
 * Orchestration complète, côté appareil :
 *   ZIP utilisateur -> extraction -> injection dans la coque -> alignement -> signature.
 */
class ApkBuilder(private val context: Context) {

    fun interface Progress { fun step(message: String) }

    fun build(
        zipUri: Uri,
        signing: SigningMaterial,
        progress: Progress
    ): File {
        val work = File(context.cacheDir, "build_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            progress.step("Extraction du ZIP…")
            val extracted = File(work, "web").apply { mkdirs() }
            ZipUtil.extract(context, zipUri, extracted)
            val webRoot = WebRootFinder.find(extracted)

            progress.step("Préparation de la coque…")
            val template = File(work, "shell-template.apk")
            context.assets.open("shell-template.apk").use { input ->
                template.outputStream().use { input.copyTo(it) }
            }

            progress.step("Injection des fichiers web + alignement…")
            val unsigned = File(work, "app-unsigned.apk")
            ApkRewriter.rebuild(template, webRoot, unsigned)

            progress.step("Signature de l'APK…")
            val outDir = File(context.filesDir, "output").apply { mkdirs() }
            val signed = File(outDir, "app-release-${System.currentTimeMillis()}.apk")
            ApkSignerHelper.sign(unsigned, signed, signing)

            progress.step("Terminé.")
            return signed
        } finally {
            work.deleteRecursively()
        }
    }
}
