package com.example.apkmaker

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

/** Extraction de ZIP avec protection contre le zip-slip, partagée par le build et l'aperçu. */
object ZipUtil {
    fun extract(context: Context, uri: Uri, destDir: File) {
        destDir.mkdirs()
        val destPath = destDir.canonicalPath + File.separator
        context.contentResolver.openInputStream(uri).use { input ->
            ZipInputStream(input!!).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    val target = File(destDir, name)
                    if (!target.canonicalPath.startsWith(destPath)) {
                        throw SecurityException("Chemin dangereux dans le ZIP : $name")
                    }
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
    }
}
