package com.example.apkmaker

import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Security
import java.security.cert.X509Certificate
import java.util.Date

data class SigningMaterial(val privateKey: PrivateKey, val certificate: X509Certificate)

/**
 * Génère ou charge un keystore PKCS12 *exportable* (la clé privée doit pouvoir être lue
 * pour signer l'APK — c'est pourquoi on n'utilise PAS AndroidKeyStore, qui ne permet pas
 * l'export de la clé privée).
 */
object KeystoreManager {

    init {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(BouncyCastleProvider())
        }
    }

    /** Crée un keystore PKCS12 auto-signé valide ~27 ans et le sauvegarde sur disque. */
    fun generate(
        out: File,
        alias: String,
        storePassword: CharArray,
        keyPassword: CharArray,
        commonName: String = "CN=ZipToAPK"
    ) {
        val kpg = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val keyPair = kpg.generateKeyPair()

        val now = System.currentTimeMillis()
        val notBefore = Date(now)
        val notAfter = Date(now + 10000L * 24 * 60 * 60 * 1000) // ~27 ans
        val subject = X500Name(commonName)

        val signer = JcaContentSignerBuilder("SHA256withRSA").build(keyPair.private)
        val holder = JcaX509v3CertificateBuilder(
            subject,
            BigInteger.valueOf(now),
            notBefore,
            notAfter,
            subject,
            keyPair.public
        ).build(signer)
        val cert = JcaX509CertificateConverter().getCertificate(holder)

        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry(alias, keyPair.private, keyPassword, arrayOf(cert))
        out.outputStream().use { ks.store(it, storePassword) }
    }

    fun load(
        file: File,
        alias: String,
        storePassword: CharArray,
        keyPassword: CharArray,
        type: String = "PKCS12"
    ): SigningMaterial {
        val ks = KeyStore.getInstance(type)
        file.inputStream().use { ks.load(it, storePassword) }
        val key = ks.getKey(alias, keyPassword) as PrivateKey
        val cert = ks.getCertificate(alias) as X509Certificate
        return SigningMaterial(key, cert)
    }

    /** Empreinte SHA-256 du certificat, format hexadécimal séparé par ":". */
    fun sha256Fingerprint(cert: X509Certificate): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(cert.encoded).joinToString(":") { "%02X".format(it) }
    }
}
