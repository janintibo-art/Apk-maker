package com.example.apkmaker

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = ViewModelProvider(this)[BuildViewModel::class.java]
        setContent {
            MaterialTheme {
                Surface {
                    BuildScreen(
                        vm = vm,
                        onShare = ::share,
                        onStartPreview = { startActivity(Intent(this, PreviewActivity::class.java)) },
                        onPinShortcut = { label -> PreviewManager.pinShortcut(this, label) }
                    )
                }
            }
        }
    }

    private fun share(apk: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Installer / partager l'APK"))
    }
}

class BuildViewModel(app: Application) : AndroidViewModel(app) {
    var status by mutableStateOf("Prêt.")
    var building by mutableStateOf(false)
    var result by mutableStateOf<File?>(null)
    var fingerprint by mutableStateOf<String?>(null)
    var keystoreInfo by mutableStateOf<String?>(null)
    var previewReady by mutableStateOf(false)

    private fun debugSigning(): SigningMaterial {
        val ctx = getApplication<Application>()
        val f = File(ctx.filesDir, "debug.p12")
        if (!f.exists()) {
            KeystoreManager.generate(f, "androiddebug", "android".toCharArray(), "android".toCharArray(), "CN=Android Debug")
        }
        return KeystoreManager.load(f, "androiddebug", "android".toCharArray(), "android".toCharArray())
    }

    /** Aperçu instantané, sans APK. */
    fun preparePreview(zip: Uri, onReady: () -> Unit) {
        if (building) return
        building = true; result = null; status = "Préparation de l'aperçu…"
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { PreviewManager.prepare(getApplication(), zip) }
                previewReady = true
                status = "Aperçu prêt."
                onReady()
            } catch (e: Exception) { status = "Erreur : ${e.message}" } finally { building = false }
        }
    }

    /** Génère un APK signé avec une clé de debug persistante et l'installe localement. */
    fun installLocally(zip: Uri) {
        if (building) return
        building = true; result = null; status = "Génération de l'app de test…"
        viewModelScope.launch {
            try {
                val ctx = getApplication<Application>()
                if (!ApkInstaller.canInstall(ctx)) {
                    status = "Autorise d'abord « installer des applications inconnues » pour cette app."
                    ApkInstaller.openUnknownSourcesSettings(ctx)
                    return@launch
                }
                val mat = withContext(Dispatchers.IO) { debugSigning() }
                val apk = withContext(Dispatchers.IO) { ApkBuilder(ctx).build(zip, mat) { status = it } }
                status = "Installation… confirme la fenêtre système."
                ApkInstaller.install(ctx, apk)
            } catch (e: Exception) { status = "Erreur : ${e.message}" } finally { building = false }
        }
    }

    /** Génère un APK release signé (clé fournie ou auto) pour partage/distribution. */
    fun generateForShare(zip: Uri, keystoreUri: Uri?, alias: String, storePass: String, keyPass: String) {
        if (building) return
        building = true; result = null; fingerprint = null; keystoreInfo = null
        viewModelScope.launch {
            try {
                val ctx = getApplication<Application>()
                val material = withContext(Dispatchers.IO) {
                    val ksFile = File(ctx.filesDir, "signing.p12")
                    val sp = storePass.ifBlank { "android" }
                    val kp = keyPass.ifBlank { sp }
                    val al = alias.ifBlank { "release" }
                    if (keystoreUri != null) {
                        ctx.contentResolver.openInputStream(keystoreUri).use { input ->
                            ksFile.outputStream().use { input!!.copyTo(it) }
                        }
                    } else if (!ksFile.exists()) {
                        KeystoreManager.generate(ksFile, al, sp.toCharArray(), kp.toCharArray())
                        keystoreInfo = "Keystore généré (alias=$al, mdp=$sp), conservé dans signing.p12."
                    }
                    KeystoreManager.load(ksFile, al, sp.toCharArray(), kp.toCharArray())
                }
                fingerprint = KeystoreManager.sha256Fingerprint(material.certificate)
                val apk = withContext(Dispatchers.IO) { ApkBuilder(ctx).build(zip, material) { status = it } }
                result = apk
                status = "APK généré : ${apk.name}"
            } catch (e: Exception) { status = "Erreur : ${e.message}" } finally { building = false }
        }
    }
}

@Composable
fun BuildScreen(
    vm: BuildViewModel,
    onShare: (File) -> Unit,
    onStartPreview: () -> Unit,
    onPinShortcut: (String) -> Unit
) {
    var zipUri by remember { mutableStateOf<Uri?>(null) }
    var keystoreUri by remember { mutableStateOf<Uri?>(null) }
    var appName by remember { mutableStateOf("Mon Appli") }
    var alias by remember { mutableStateOf("release") }
    var storePass by remember { mutableStateOf("") }
    var keyPass by remember { mutableStateOf("") }
    var showShare by remember { mutableStateOf(false) }

    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) zipUri = uri
    }
    val pickKeystore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        keystoreUri = uri
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ZIP → App de test (sur l'appareil)", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Teste ton site comme une app, sans qu'aucun fichier ne quitte le téléphone.",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(appName, { appName = it }, label = { Text("Nom (pour le raccourci)") }, modifier = Modifier.fillMaxWidth())

        Button(onClick = { pickZip.launch(arrayOf("application/zip", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) {
            Text(zipUri?.let { "ZIP : ${it.lastPathSegment}" } ?: "Choisir le ZIP du site")
        }

        Text("Test local", fontWeight = FontWeight.Bold)
        Button(
            onClick = { zipUri?.let { vm.preparePreview(it) { onStartPreview() } } },
            enabled = zipUri != null && !vm.building,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Aperçu instantané (sans APK)") }

        if (vm.previewReady) {
            OutlinedButton(onClick = { onPinShortcut(appName) }, modifier = Modifier.fillMaxWidth()) {
                Text("Ajouter un raccourci d'aperçu à l'accueil")
            }
        }

        Button(
            onClick = { zipUri?.let { vm.installLocally(it) } },
            enabled = zipUri != null && !vm.building,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Installer comme app de test") }

        Divider(Modifier.padding(vertical = 4.dp))

        TextButton(onClick = { showShare = !showShare }) {
            Text(if (showShare) "Masquer le partage (release signé)" else "Générer un APK à partager (avancé)")
        }

        if (showShare) {
            OutlinedTextField(alias, { alias = it }, label = { Text("Alias de clé") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                storePass, { storePass = it }, label = { Text("Mot de passe keystore") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                keyPass, { keyPass = it }, label = { Text("Mot de passe clé (vide = idem)") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(onClick = { pickKeystore.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text(keystoreUri?.let { "Keystore : ${it.lastPathSegment}" } ?: "Keystore existant (optionnel)")
            }
            Button(
                onClick = { zipUri?.let { vm.generateForShare(it, keystoreUri, alias, storePass, keyPass) } },
                enabled = zipUri != null && !vm.building,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Générer l'APK à partager") }
        }

        if (vm.building) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(vm.status, style = MaterialTheme.typography.bodyMedium)
        vm.keystoreInfo?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        vm.fingerprint?.let { Text("SHA-256 : $it", style = MaterialTheme.typography.bodySmall) }

        vm.result?.let { apk ->
            Button(onClick = { onShare(apk) }, modifier = Modifier.fillMaxWidth()) {
                Text("Partager l'APK")
            }
        }
    }
}
