package com.example.apkmaker

import java.io.BufferedOutputStream
import java.io.File
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Reconstruit un APK à partir d'un APK modèle (la coque) :
 *  - retire les anciennes signatures (META-INF/*.SF, *.RSA, *.MF) et l'ancien assets/public,
 *  - réinjecte les fichiers web de l'utilisateur sous assets/public/,
 *  - aligne les entrées STORED (resources.arsc, *.so) comme le ferait zipalign.
 *
 * Stratégie d'alignement : on écrit d'abord toutes les entrées STORED (les seules qui
 * doivent être alignées), à des offsets contrôlés via le champ "extra" du header local ;
 * puis toutes les entrées DEFLATED (compressées, sans contrainte d'alignement). On évite
 * ainsi de devoir recalculer l'alignement d'entrées situées après des suppressions.
 *
 * L'APK produit est NON signé : passer ensuite par ApkSignerHelper.
 */
object ApkRewriter {

    private const val ALIGN_DEFAULT = 4
    private const val ALIGN_SO = 16384            // page 16 Ko (Android 15+)
    private const val ALIGN_EXTRA_ID = 0xD935     // marqueur d'alignement (cf. AGP/zipflinger)

    private class CountingOutputStream(out: OutputStream) : FilterOutputStream(out) {
        var count: Long = 0; private set
        override fun write(b: Int) { super.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private fun isOldSignature(name: String): Boolean =
        name.startsWith("META-INF/") &&
            (name.endsWith(".SF") || name.endsWith(".RSA") || name.endsWith(".DSA") ||
                name.endsWith(".EC") || name.endsWith("MANIFEST.MF"))

    private fun alignFor(name: String): Int = if (name.endsWith(".so")) ALIGN_SO else ALIGN_DEFAULT

    fun rebuild(templateApk: File, webRoot: File, out: File) {
        ZipFile(templateApk).use { zin ->
            val all = zin.entries().toList().filterNot { it.isDirectory }
            val keep = all.filterNot { isOldSignature(it.name) || it.name.startsWith("assets/public/") }
            val stored = keep.filter { it.method == ZipEntry.STORED }
            val compressed = keep.filter { it.method != ZipEntry.STORED }

            val counting = CountingOutputStream(BufferedOutputStream(out.outputStream()))
            ZipOutputStream(counting).use { zos ->
                // 1) entrées STORED en tête, alignées
                for (e in stored) {
                    val data = zin.getInputStream(e).readBytes()
                    writeStoredAligned(zos, counting, e.name, data, alignFor(e.name))
                }
                // 2) entrées compressées d'origine
                for (e in compressed) {
                    val ne = ZipEntry(e.name).apply { method = ZipEntry.DEFLATED }
                    zos.putNextEntry(ne)
                    zin.getInputStream(e).use { it.copyTo(zos) }
                    zos.closeEntry()
                }
                // 3) fichiers web de l'utilisateur (compressés) sous assets/public/
                addTree(zos, webRoot, "assets/public")
            }
        }
    }

    private fun writeStoredAligned(
        zos: ZipOutputStream,
        counting: CountingOutputStream,
        name: String,
        data: ByteArray,
        align: Int
    ) {
        val crc = CRC32().apply { update(data) }
        val entry = ZipEntry(name).apply {
            method = ZipEntry.STORED
            size = data.size.toLong()
            compressedSize = data.size.toLong()
            this.crc = crc.value
        }
        // Offset où débutera le champ extra : count + 30 (header local) + longueur du nom.
        val nameLen = name.toByteArray(Charsets.UTF_8).size
        val base = counting.count + 30 + nameLen
        var pad = ((align - (base % align)) % align).toInt()
        if (pad in 1..3) pad += align // place pour l'en-tête extra de 4 octets
        if (pad > 0) {
            val extra = ByteArray(pad)
            val dataSize = pad - 4
            extra[0] = (ALIGN_EXTRA_ID and 0xFF).toByte()
            extra[1] = ((ALIGN_EXTRA_ID shr 8) and 0xFF).toByte()
            extra[2] = (dataSize and 0xFF).toByte()
            extra[3] = ((dataSize shr 8) and 0xFF).toByte()
            entry.extra = extra
        }
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    private fun addTree(zos: ZipOutputStream, root: File, prefix: String) {
        root.walkTopDown().filter { it.isFile }.forEach { f ->
            val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
            val ne = ZipEntry("$prefix/$rel").apply { method = ZipEntry.DEFLATED }
            zos.putNextEntry(ne)
            f.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }
}
