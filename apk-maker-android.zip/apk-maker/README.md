# APK Maker — générateur d'APK 100 % sur l'appareil (Android)

App Android native qui transforme un **ZIP de site statique (HTML/CSS/JS)** en **APK signé**,
**directement sur le téléphone**, sans PC, sans Gradle, sans SDK à l'exécution.

## Principe

L'app embarque une **coque WebView pré-compilée** (module `:shell`). À l'exécution, sur l'appareil :

1. extraction du ZIP et détection de `index.html` ;
2. ouverture de la coque (un APK modèle) comme une archive ZIP ;
3. injection des fichiers web sous `assets/public/`, suppression de l'ancien contenu et des anciennes signatures ;
4. **alignement** des entrées (équivalent `zipalign`) ;
5. **signature** V1+V2+V3 via la bibliothèque Google **`apksig`** (pur Java, tourne sur Android).

La coque charge le site via `WebViewAssetLoader` sur `https://appassets.androidx.org/` (plus robuste que `file://`).

## Trois modes

1. **Aperçu instantané (sans APK)** — le ZIP est extrait dans le stockage interne et exécuté dans une WebView (`PreviewActivity`). Rien n'est compilé ni installé ; idéal pour itérer vite. Option : épingler un **raccourci** sur l'écran d'accueil.
2. **Installer comme app de test** — l'APK est généré puis **installé sur place** via `PackageInstaller` (`ApkInstaller`), signé avec une clé de debug persistante (`debug.p12`). Le fichier ne quitte jamais le téléphone. Les réinstallations remplacent la version précédente (même clé, même package).
3. **Générer un APK à partager (avancé)** — APK release signé (clé fournie ou auto) destiné au sideload/distribution, avec empreinte SHA-256.

Pour les modes 2 et 3, autorise « installer des applications inconnues » pour cette app (l'app t'y redirige si besoin).

## Structure

```
:shell   → l'app générée (coque WebView). Produit un APK release NON signé.
:app     → le générateur (UI Compose, extraction, injection, alignement, signature).
```

Une tâche Gradle (`copyShellTemplate`) compile `:shell` et copie son APK release non signé
dans `app/src/main/assets/shell-template.apk` avant chaque build de `:app`.

## Compiler

1. Ouvre le dossier dans **Android Studio** (récent). Laisse-le télécharger le SDK et générer le wrapper Gradle.
2. Branche un appareil (ou un émulateur) et lance le module **`app`**.
3. Au premier build, `:shell` est compilé puis copié comme modèle — c'est automatique.

> Les versions (AGP, Kotlin, Compose BOM, `apksig`, BouncyCastle) sont indiquées dans les
> `build.gradle.kts`. Si Android Studio propose de les harmoniser, accepte.

## Utiliser

1. Choisis le **ZIP** du site.
2. Indique alias + mot de passe ; laisse le keystore vide pour en **générer un** (`signing.p12` stocké dans les fichiers de l'app), ou sélectionne un keystore PKCS12 existant.
3. **Générer l'APK** → suis la progression → **Installer / partager**.
4. Sur l'appareil, autorise l'**installation depuis des sources inconnues**.

## ⚠️ Limites de ce prototype (à lire)

- **Non compilé/testé par moi** : c'est un squelette fonctionnel à valider sur un vrai appareil (surtout l'étape alignement + signature : installe et lance l'APK produit pour confirmer).
- **Package fixe** : toutes les apps générées portent `com.example.generatedapp`. Conséquences :
  - impossible d'installer deux apps générées différentes côte à côte ;
  - inadapté à plusieurs fiches distinctes sur le Play Store.
  - Changer le package **par app** impose de recompiler `resources.arsc` avec **aapt2** (binaire ARM64) — non couvert ici. Pour un usage perso/sideload avec un package unique, le prototype suffit.
- **Nom d'app** : c'est le `label` de la coque (`@string/app_name` du module `:shell`). Le rendre dynamique exige de patcher le manifeste binaire (aapt2) — non couvert.
- **Signature** : on n'utilise pas AndroidKeyStore (qui interdit l'export de la clé privée) mais un PKCS12 exportable via BouncyCastle. Garde `signing.p12` + mots de passe à l'identique pour les mises à jour.
- **Distribution** : l'app génératrice se distribue en sideload ; une app qui en fabrique d'autres peut enfreindre les règles du Play Store.

## Pistes pour aller plus loin

- Intégrer **aapt2** (ARM64) pour package + label personnalisés par app.
- Icône/splash dynamiques (réécriture des ressources via aapt2).
- Vérification d'installation automatique (`PackageInstaller`).
