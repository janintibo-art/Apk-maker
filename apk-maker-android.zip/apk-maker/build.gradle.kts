// Versions ajustables : laisse Android Studio harmoniser AGP / Kotlin si besoin.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
