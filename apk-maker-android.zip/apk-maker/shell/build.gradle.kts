plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.apkshell"
    compileSdk = 34

    defaultConfig {
        // ⚠️ Package FIXE de la coque. Voir README : changer le package par app
        // nécessite aapt2 (recompilation des ressources), non couvert par ce prototype.
        applicationId = "com.example.generatedapp"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // Pas de signingConfig : on veut un APK release NON signé,
            // qui servira de modèle injecté + signé sur l'appareil.
            isMinifyEnabled = false
        }
    }
    // Empêche lintVitalRelease de bloquer le build de la coque (ex. ExpiredTargetSdkVersion).
    lint {
        checkReleaseBuilds = false
        abortOnError = false
        disable += "ExpiredTargetSdkVersion"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
