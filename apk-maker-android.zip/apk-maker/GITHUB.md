# Construire l'APK sur GitHub (sans PC ni Android Studio)

Ce projet contient un workflow GitHub Actions (`.github/workflows/build-apk.yml`) qui
compile l'APK **sur les serveurs de GitHub** et te le donne en téléchargement.

## Étapes

1. Crée un dépôt sur GitHub (privé ou public).
2. Ajoute-y le contenu de ce projet **à la racine du dépôt**, de sorte que :
   - `settings.gradle.kts` soit à la racine,
   - `.github/workflows/build-apk.yml` existe bien (les workflows ne sont lus qu'à la racine).
   - Le plus simple : sur la page du dépôt, *Add file → Upload files*, puis dépose tous les
     fichiers/dossiers. (Tu peux aussi déposer directement le `.zip` : le workflow l'extrait.)
3. Valide (commit). Le workflow se lance automatiquement.
4. Onglet **Actions** → ouvre le run le plus récent → attends la fin (quelques minutes).
5. En bas du run, section **Artifacts** → télécharge **`app-debug-apk`** (un `.zip`
   contenant `app-debug.apk`).
6. Décompresse, transfère l'APK sur ton téléphone, installe-le (autorise les sources inconnues).

## Lancer manuellement

Onglet **Actions** → *Build APK* → bouton **Run workflow**.

## Obtenir l'APK via une Release (lien direct, durable)

Crée une **Release** (onglet *Releases → Draft a new release → Publish*). Le workflow
attache automatiquement `app-debug.apk` à la Release : tu obtiens un lien de téléchargement
direct, pratique à installer depuis le téléphone.

## Ce que fait le workflow

- récupère le code (et extrait un `.zip` du projet s'il en trouve un) ;
- installe JDK 17, le SDK Android (licences acceptées) et Gradle 8.7 ;
- lance `gradle :app:assembleDebug` — ce qui compile aussi le module `:shell` et copie sa
  coque dans les assets ;
- publie `app-debug.apk` en artifact (et sur la Release le cas échéant).

L'APK produit est en **debug**, signé automatiquement par la clé de debug d'Android : il
s'installe directement. Pour un APK **release signé** par ta propre clé, il faudrait ajouter
un keystore en *secret* GitHub et une étape de signature — dis-le-moi si tu veux cette variante.

## Remarques

- Les versions (AGP 8.5.2, Kotlin 1.9.24, Compose 1.5.14, Gradle 8.7) sont cohérentes ; si un
  jour une incompatibilité apparaît, le log Actions l'indique et il suffit d'ajuster une version.
- Le fichier `app/src/main/assets/shell-template.apk` est volontairement ignoré par git
  (`.gitignore`) : il est régénéré à chaque build par le module `:shell`.
